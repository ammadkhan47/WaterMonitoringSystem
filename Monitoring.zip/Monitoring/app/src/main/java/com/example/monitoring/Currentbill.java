package com.example.monitoring;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Currentbill extends AppCompatActivity {
    TextView tv29;
    Button btn10;

    DatabaseReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currentbill);


        tv29=findViewById(R.id.textView29);
        btn10=findViewById(R.id.button10);

        EditText editText;
        String query="1-7-2020";

        btn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Generatebill.class));
            }
        });



        db= FirebaseDatabase.getInstance().getReference().child("Consumption");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                String templ= dataSnapshot.child("03-07-2020").getValue().toString() ;

                Double a= (Float.valueOf(templ))*0.95;
                templ = String.valueOf(a);

                tv29.setText(templ+"Rs");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });





    }
}
