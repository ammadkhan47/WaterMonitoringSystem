package com.example.monitoring;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Datebill extends AppCompatActivity {

    DatabaseReference db;
    TextView tv31;
    EditText editText;
    String query="";
    Button btn11,btn12;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datebill);

        btn11=findViewById(R.id.button11);

        tv31=findViewById(R.id.textView31);

        btn12=findViewById(R.id.button12);


        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Generatebill.class));
            }
        });

        btn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                data();
            }
        });



    }




    public void data(){
        db= FirebaseDatabase.getInstance().getReference().child("Consumption");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                editText=findViewById(R.id.editText);
                query=editText.getText().toString();

                String templ= dataSnapshot.child(query).getValue().toString() ;

                Double a= (Float.valueOf(templ))*0.95;
                templ = String.valueOf(a);

                tv31.setText(templ+"Rs");


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}


