package com.example.monitoring;

public class Member {

    private int temp;
    private int turb;
    private int ph;


    public Member(){

    }

    public int getTemp() {
        return temp;
    }

    public void setTemp(int temp) {
        this.temp = temp;
    }

    public int getTurb() {
        return turb;
    }

    public void setTurb(int turb) {
        this.turb = turb;
    }

    public int getPh() {
        return ph;
    }

    public void setPh(int ph) {
        this.ph = ph;
    }

  
}
